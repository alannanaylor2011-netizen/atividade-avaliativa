// Garante que o código só rode após todo o HTML ser carregado
document.addEventListener("DOMContentLoaded", () => {

    // Array para armazenar os filmes na memória da página
    let filmes = [];

    // Seleção dos elementos do DOM usando os IDs do seu HTML
    const formFilmes = document.getElementById("formFilmes");
    const inputNome = document.getElementById("nome"); // Seu input de título usa id="nome"
    const inputSinopse = document.getElementById("sinopse");
    const inputAno = document.getElementById("ano");
    const inputBusca = document.getElementById("busca");
    const gridFilmes = document.getElementById("grid-filmes");

    // Criando dinamicamente um container para mensagens de feedback
    const mensagemFeedback = document.createElement("div");
    mensagemFeedback.className = "hidden fixed top-4 right-4 p-4 rounded-md shadow-lg text-white font-medium z-50 transition-all duration-300";
    document.body.appendChild(mensagemFeedback);

    // Função para mostrar alertas de sucesso ou erro na tela
    const exibirMensagem = (texto, tipo) => {
        mensagemFeedback.innerText = texto;
        mensagemFeedback.classList.remove("hidden", "bg-green-600", "bg-red-600");

        if (tipo === "sucesso") {
            mensagemFeedback.classList.add("bg-green-600");
        } else {
            mensagemFeedback.classList.add("bg-red-600");
        }

        // Remove a mensagem após 3 segundos
        setTimeout(() => {
            mensagemFeedback.classList.add("hidden");
        }, 3000);
    };

    // Função que atualiza o grid e exibe a lista na página
    const renderizarFilmes = (listaParaExibir) => {
        // Limpa o grid antes de desenhar os novos itens
        gridFilmes.innerHTML = "";

        if (listaParaExibir.length === 0) {
            gridFilmes.innerHTML = `<p class="text-gray-500 text-center col-span-full py-4">Nenhum filme cadastrado.</p>`;
            return;
        }

        // Ordena os filmes: Ano mais recente primeiro (decrescente)
        const filmesOrdenados = [...listaParaExibir].sort((a, b) => b.ano - a.ano);

        // Percorre a lista e insere os cards no grid
        filmesOrdenados.forEach(filme => {
            const card = document.createElement("div");
            // Usando col-span-3 para se ajustar bem ao seu grid-cols-3 do Tailwind
            card.className = "col-span-3 bg-slate-50 border border-slate-200 rounded-lg p-4 flex flex-col justify-between shadow-xs";

            card.innerHTML = `
                <div>
                    <div class="flex justify-between items-start gap-2 mb-2">
                        <h3 class="font-bold text-base text-slate-900 break-words">${filme.titulo}</h3>
                        <span class="bg-indigo-100 text-indigo-800 text-xs font-semibold px-2 py-0.5 rounded-sm whitespace-nowrap">${filme.ano}</span>
                    </div>
                    <p class="text-slate-600 text-xs italic break-words">"${filme.sinopse}"</p>
                </div>
            `;
            gridFilmes.appendChild(card);
        });
    };

    // Evento 'submit' do formulário (Cadastro do filme)
    formFilmes.addEventListener("submit", (event) => {
        // Impede o recarregamento padrão da página
        event.preventDefault();

        // Manipulação de String: removendo espaços extras e convertendo para Caixa Alta
        const tituloLimpo = inputNome.value.trim().toUpperCase();
        const sinopseLimpa = inputSinopse.value.trim();
        const anoValor = parseInt(inputAno.value);

        // Validação extra de segurança
        if (!tituloLimpo || !sinopseLimpa || !anoValor) {
            exibirMensagem("Preencha todos os campos obrigatórios!", "erro");
            return;
        }

        // Criando o objeto do filme
        const novoFilme = {
            titulo: tituloLimpo,
            sinopse: sinopseLimpa,
            ano: anoValor
        };

        // Manipulação de Array: adicionando o novo item ao final
        filmes.push(novoFilme);

        // Mostra o aviso de sucesso
        exibirMensagem(`Filme "${tituloLimpo}" cadastrado!`, "sucesso");

        // Reseta todos os campos do formulário de forma limpa
        formFilmes.reset();
        inputBusca.value = ""; // Limpa a busca caso o usuário estivesse filtrando

        // Atualiza a interface gráfica
        renderizarFilmes(filmes);
    });

    // Evento 'input' no campo de busca (Filtragem em tempo real)
    inputBusca.addEventListener("input", () => {
        const termoBusca = inputBusca.value.trim().toUpperCase();

        // Manipulação de Array: filtra os filmes que contêm o termo digitado no título
        const filmesFiltrados = filmes.filter(filme =>
            filme.titulo.includes(termoBusca)
        );

        // Renderiza apenas os resultados que passaram pelo filtro
        renderizarFilmes(filmesFiltrados);
    });
});
